function openTrackingWindow() {
    var specialCode = document.getElementById('specialCode').value.trim();

    if (specialCode !== '') {
        var trackingWindow = window.open('tracking.html', '_blank');
        trackingWindow.onload = function() {
            trackingWindow.initTracking(specialCode);
        };
    } else {
        alert('Please enter the special code.');
    }
}
