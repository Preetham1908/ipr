// Define information for each medicine
var medicines = {
    medicine1: {
        specialCode: 'ABC123',
        details: {
            Medicine_Name: 'Aspirin',
            Batch_Number: 'ABC123',
            Manufacturing_Date: '2023-01-01',
            Expiration_Date: '2026-01-01',
            Delivery_Date:  '2024-02-01'
        }
    },
    medicine2: {
        specialCode: 'XYZ456',
        details: {
            Medicine_Name: 'Ibuprofen',
            Batch_Number: 'XYZ456',
            Manufacturing_Date: '2023-02-01',
            Expiration_Date: '2026-02-01',
            Delivery_Date:  '2024-03-01'
        }
    },
    medicine3: {
        specialCode: 'DEF789',
        details: {
            Medicine_Name: 'Paracetamol',
            Batch_Number: 'DEF789',
            Manufacturing_Date: '2023-03-01',
            Expiration_Date: '2026-03-01',
            Delivery_Date:  '2024-04-01'
        }
    },
    medicine4: {
        specialCode: 'GHI012',
        details: {
            Medicine_Name: 'Antibiotic',
            Batch_Number: 'GHI012',
            Manufacturing_Date: '2023-04-01',
            Expiration_Date: '2026-04-01',
            Delivery_Date:  '2024-05-01'
        }
    },
    medicine5: {
        specialCode: 'JKL345',
        details: {
            Medicine_Name: 'Cough Syrup',
            Batch_Number: 'JKL345',
            Manufacturing_Date: '2023-05-01',
            Expiration_Date: '2026-05-01',
            Delivery_Date:  '2024-06-01'
        }
    }
};

function initTracking(specialCode) {
    var statusElement = document.getElementById('status');
    var timelineElement = document.getElementById('timeline');
    var medicineDetailsElement = document.getElementById('medicineDetails');
    
    // Reset elements
    timelineElement.innerHTML = '';
    medicineDetailsElement.innerHTML = '';

    // Find the medicine based on the special code
    var currentMedicine = findMedicineByCode(specialCode);

    if (currentMedicine) {
        var trackingStatus = ['Manufacturer', 'Distributor', 'Wholesaler', 'Retailer', 'Pharmacy'];
        var currentStatusIndex = 0;

        var intervalId = setInterval(function() {
            statusElement.textContent = 'Tracking status: ' + trackingStatus[currentStatusIndex];

            var timelineItem = document.createElement('div');
            timelineItem.className = 'timeline-item';
            timelineElement.appendChild(timelineItem);

            currentStatusIndex++;

            if (currentStatusIndex === trackingStatus.length) {
                clearInterval(intervalId);
                statusElement.textContent = 'Medicine reached the Pharmacy';
            }
        }, 1500);

        // Display medicine details
        for (var key in currentMedicine.details) {
            var listItem = document.createElement('li');
            listItem.innerHTML = `<strong>${key}:</strong> ${currentMedicine.details[key]}`;
            medicineDetailsElement.appendChild(listItem);
        }
    } else {
        // Show an error message if the special code is not found
        statusElement.textContent = 'Invalid special code. Please try again.';
    }
}

function findMedicineByCode(code) {
    // Search for the medicine with the given special code
    for (var medicine in medicines) {
        if (medicines[medicine].specialCode === code) {
            return medicines[medicine];
        }
    }
    return null; // Return null if no matching medicine is found
}
